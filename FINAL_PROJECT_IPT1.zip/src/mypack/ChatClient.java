
package mypack;

public interface ChatClient {
    void sendMessage(String message);
    void receiveMessage(String message);
}